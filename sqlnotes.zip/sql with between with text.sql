-- between using text
--select * from student where sname between 'govind' and 'rajesh'
--select * from student where sname between 'govind' and 'rajesh' order by sname
--select * from student where sname between 'govind' and 'rajesh' order by sname desc
--select * from student where sname not between 'govind' and 'rajesh' order by sname




