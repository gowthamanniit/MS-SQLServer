select * from emp1

select * from emp union select * from emp1
select * from emp union all select * from emp1