/*
sql server Date data type

date  - yyyy-mm-dd

datetime - yyyy-mm-dd hh:mi:ss

Timestamp - number

*/

--create table emp5 (eno int,ename varchar(22),edob date)
--insert into emp5 values(101,'raja','2020-11-28')
--select * from emp5
--create table emp6 (eno int,ename varchar(22),sdd datetime)
--insert into emp6 values(101,'raja','2021-11-28 13:11:12')
--select * from emp6

create table emp8 (eno int,ename varchar(22),sdd timestamp)






