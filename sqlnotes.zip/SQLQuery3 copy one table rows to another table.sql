select * from emp
select * from emp1
insert into emp1  select * from emp where eno<1003
