--select abs(-12)
--select * from student where mark1>0
--select count(mark1)from student where mark1>0
--select avg(mark1) from student where mark1>0
--select sum(mark1) from student where mark1>0
--select ceiling(12.001)
--select floor(12.99)
--select max(mark1) from student where mark1>0
--select min(mark1) from student where mark1>0
--select pi()
--select power(2,5)
--select ceiling(rand()*10)
--select round(12.46454,0,0)
--select round(12.46554,2,0)
--select round(12.46554,1)
--select sign(0)
--select sqrt(49)
--select square(4)
--select CURRENT_TIMESTAMP -- net date and time
--select getdate()  -- system date and time
--select dateadd(DAY,10,'25-feb-2020')
--select dateadd(month,10,'25-feb-2020')
--select dateadd(year,10,'25-feb-2020')
--select datediff(year,'04-jul-1983',getdate())
--select datediff(month,'04-jul-1983',getdate())
--select datediff(day,'04-jul-1983',getdate())
--select datediff(hour,'04-jul-1983',getdate())
--select datediff(MINUTE,'04-jul-1983',getdate())
--select datediff(second,'04-jul-1983',getdate())
--select day(getdate())
--select month(getdate())
--select year(getdate())
--select isdate('29-feb-2020')

select cast('454' as int)
select cast(454 as varchar)
select CURRENT_USER
select SYSTEM_USER











