/*Sql Server String function*/
--select ascii('A')
--select ascii('a')
--select ascii('0')
--select char(97)
--select charindex('i','sivaranjani',3)
--select concat('abc','ede','gee','safsdf')
--select left('sivaranjanani',4)
--select len('karur')
--select lower('SHIVA-karur')
--select lower('SHIVA-karur')
--select upper('SHIVA-karur')
--select len(ltrim('    abcd'))
--select replace('karur','r','o')
--select replicate('karur',10)
--select reverse('gowthaman')
--select right('gowthaman',5);
--select 'abcd'+rtrim('   gowthaman    ')+'abcd'
--select 'abcd'+ltrim('   gowthaman    ')+'abcd'
--select 'abcd'+rtrim(ltrim('   gowthaman    '))+'abcd'
--select space(15)+'aa'
--select str(12)+str(12)
--select substring('sivaranjani',3,5)
--select format(1234454535,'##-(###)-####')

--select stuff('karur',1,3,'xxxx')
--deletes a part of string and then insert another string.








