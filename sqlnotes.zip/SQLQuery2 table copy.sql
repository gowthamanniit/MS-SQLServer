select * from emp
select * from emp2
truncate table emp2

--select * into emp2 from emp
--select * into siva from emp
select * from siva

/*syntax:

select * into newtablename from oldtablename

*/
--delete from siva where eno>1003



select eno,ename into ram from emp

select * from ram

select eno,ename into gowtham from emp where eno>1003
select * from gowtham

create database sivaranjani






















