--createa database college
--use college
--create table stud(sno int,sname varchar(22),mark int)
--insert into stud values(13,'govi',77)
--select * from stud


--backup database college
--to disk = 'd:/sivaranjani/college.bak'

--drop database college

--restore database college
--from disk = 'd:/sivaranjani/college.bak'


select * from stud





