select * from emp
--alter table emp add test int

/*  change the table column datatype  */

/*
 syntax:
 alter table tablename alter column columnname datatype

*/
alter table emp alter column test varchar(25)
