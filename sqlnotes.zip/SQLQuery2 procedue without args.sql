/*
create procedure myprocedure
as
select * from emp1
go;
*/
exec myprocedure
