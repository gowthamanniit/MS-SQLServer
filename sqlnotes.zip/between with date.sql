--create table emp(eno int,ename varchar(33),dob date)
--insert into emp values(1005,'govindan','21-jan-2021')
select * from emp
select * from emp where dob between '12-jan-2021' and '28-feb-2021'
